package com.example.numero_3;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.RequestQueue;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {
    TextView nombre_maman;
    int nb=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        nombre_maman = findViewById(R.id.nombre_maman);
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = "https://api.jsonbin.io/v3/b/6763118eacd3cb34a8bbdcb1?meta=false";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        //parseJsonAndAddToList(response); // methode pour ajouter au lieux de coder a l'intérieur
                        Toast.makeText(getApplicationContext(), "marche", Toast.LENGTH_LONG).show();

                        JSONArray tab = null;
                        try {

                            tab = (JSONArray) response.get("cadeaux");

                            for(int i=0; i < tab.length(); i++){
                                JSONObject le_premier = tab.getJSONObject(i);
                                String provenance = (String) le_premier.get("provenance");
                                if(provenance.equals("Maman")){nb++;}
                            }
                            String nbString = String.valueOf(nb);
                            nombre_maman.setText(nbString);

                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Toast.makeText(getApplicationContext(), "Erreur lors de la récupération des données", Toast.LENGTH_LONG).show();
            }
        });

        queue.add(jsonObjectRequest);


    }



}